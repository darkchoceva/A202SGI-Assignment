package com.example.easynote.listeners;

import com.example.easynote.entities.Note;

public interface NotesListener {
    void onNoteClicked(Note note, int pos);
}
